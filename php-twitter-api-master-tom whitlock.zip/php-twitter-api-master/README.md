# General purpose Twitter API 1.1 client for PHP

See examples for usage.

Better docs to follow soon.

## Authorizing an app from the command line

First retrieve or generate a [consumer key and a consumer secret](https://dev.twitter.com/apps).

From the commandline run `php authorize.php` and follow the prompts.

In the end you will be given an access key and an access secret which you can use with the [Twitter API](https://dev.twitter.com/docs/api/1.1). 
